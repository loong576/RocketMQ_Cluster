package org.apache.rocketmq.connect.jms;

public class ErrorCode {

    public static final int START_ERROR_CODE = 10001;

    public static final int STOP_ERROR_CODE = 10002;
}
